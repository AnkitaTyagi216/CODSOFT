/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class NumberGame
{
	public static void main(String[] args) {
	    Scanner scanner=new Scanner(System.in);
	    int chances=8;
	    int finals=0;
	    boolean playAgain=true;
		System.out.println("Welcome Buddy!");
		System.out.println("Hey Buddy you have about "+chances+" chances to win the game");
		while(playAgain){
		    int random=getrandomN(1,100);
		    boolean guess=false;
		    for(int i=0;i<chances;i++){
		        System.out.println("Chance"+(i+1)+"   Enter your guess:");
		        int user=scanner.nextInt();
		        if(user==random){
		            guess=true;
		            finals+=1;
		            System.out.println("You won it");
		            break;
		        }
		        else if(user>random){
		            System.out.println("Too high");
		        }
		        else{
		            System.out.println("Too low");
		        }
		    }
		    if(guess==false){
		        System.out.println("Sorry Buddy, You lost the chances.The number is "+random);
		    }
		    System.out.println("Do you want to play Again(y/n)");
		    String pA=scanner.next();
		    playAgain=pA.equalsIgnoreCase("y");
		}
		System.out.println("That's it Buddy, Hope you enjoyed it");
		System.out.println("Here is your Score"+finals);
	}
		public static int getrandomN(int min,int max){
		    return(int)(Math.random()*(max-min+1)+min);
		}
}
